import sys
import RPi.GPIO as GPIO
from time import sleep
import pygame
from Tkinter import *


led = 16
GPIO.setmode(GPIO.BCM)
GPIO.setup(led, GPIO.OUT)



def start_gui():
		'''Starting point when module is the main routine.'''
		global val, w, root
		root = Tk()
		top = Inside_display (root)
		root.mainloop()

w = None
def create_New_Toplevel(root, *args, **kwargs):
		'''Starting point when module is imported by another program.'''
		global w, w_win, rt
		rt = root
		w = Toplevel (root)
		top = Inside_display (w)
		return (w, top)

def destroy_Inside_display():
		global w
		w.destroy()
		w = None




# class that creates the Inside display
class Inside_display:
		def __init__(self, top=None):
				

				# This class configures and populates the toplevel window.
				# top is the toplevel containing window.
				_bgcolor = '#d9d9d9'  # X11 color: 'gray85'
				_fgcolor = '#000000'  # X11 color: 'black'
				_compcolor = '#d9d9d9' # X11 color: 'gray85'
				_ana1color = '#d9d9d9' # X11 color: 'gray85' 
				_ana2color = '#d9d9d9' # X11 color: 'gray85' 
				font11 = "-family {Times New Roman} -size 30 -weight normal "  \
								"-slant roman -underline 0 -overstrike 0"

				top.geometry("800x480")
				top.title("Jarvis")
				top.configure(background="#2b287a")
				top.configure(highlightbackground="#d9d9d9")
				top.configure(highlightcolor="black")

				
				def panic():
												# panic function is called when its button is pressed
						pygame.init()
						counter = 0
						# play the alarm sound 10 times 
						while (counter < 10):
							pygame.mixer.Sound("Air_Horn.wav").play()
							sleep(.2)
							counter += 1
										
				def lock():
																# a red LED is used to represent locking/unlocking the door
								GPIO.output(led, GPIO.HIGH)
								# waits 10 seconds
								sleep(10)
								GPIO.output(led, GPIO.LOW)

				

				# creates the panic button at the top right of the gui
				Button1 = Button(top)
				# sets the button in it's appropriate place at its appropriate size
				Button1.place(relx=0.84, rely=0.07, height=110, width=96)
				# when the button is pressed the back ground changes color
				Button1.configure(activebackground="#d9d9d9")
				# sets the back ground color
				Button1.configure(background="black")
				# sets the width of the border
				Button1.configure(borderwidth="10")
				# when the button is pressed it calls the appropriate function 
				Button1.configure(command=lambda:panic())
				# when the mouse is over the button it changes the arrow to a hand 
				Button1.configure(cursor="hand2")
				_img1 = PhotoImage(file="sos.gif")
				Button1.configure(image=_img1)
				Button.image=_img1
				Button1.configure(pady="0")
				Button1.configure(width=96)
				
				# creates the unlock button under the panic button
				Button1_2 = Button(top)
				Button1_2.place(relx=0.84, rely=0.38, height=110, width=96)
				_img3 = PhotoImage(file="Lock-icon.gif")
				Button1_2.configure(activebackground="#d9d9d9", background="#7a7a7a", borderwidth="10", command=lambda:lock(), cursor="hand2", image=_img3, pady="0", width=96)
				Button1_2.image=_img3
				
				# creates the lock button under the unlock button
				Button1_3 = Button(top)
				Button1_3.place(relx=0.84, rely=0.69, height=110, width=96)
				_img4 = PhotoImage(file="Unlock-icon.gif")
				Button1_3.configure(activebackground="#d9d9d9", background="black", borderwidth="10", command=lambda:lock(), cursor="hand2", image=_img4, pady="0", width=96)
				Button1_3.image=_img4
				


if __name__ == '__main__':
		start_gui()
