from picamera import PiCamera
from time import *
import RPi.GPIO as GPIO


GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
GPIO.setup(17, GPIO.IN)

camera = PiCamera()

# displays the camera feed ont the screen
camera.start_preview(fullscreen = False, window = (13,39, 645,480))
recording = False
# keeps track of which file to save the recording
history = 1

try:
	while True:
		i=GPIO.input(17)
		#When output from motion sensor is LOW
		if i==1:
			# if the motion sensor detects motion and if it is not currently recording then it will start recording
			if recording:
				# if it is recording it waits 0.1 seconds then checks again
				camera.wait_recording(0.1)
			else:
				# if it is not recording then it starts recording 
				camera.start_recording('/home/pi/Desktop/{}.h264'. format(history))
				recording = True
				print "Recording"
		#When output from motion sensor is HIGH		
		else:
			# if the motion sensor does not detect anyone it will record for 5 seconds
			# then stop recoding 
			if recording:
				sleep(5)
				camera.stop_recording()
				print "stop recording"
				# this will keep the past 6 recordings then begin to loop over them
				if (history > 5):
					history = 1
					recording = False
				else:
					history += 1
					recording = False
			

except KeyboardInterrupt:
	GPIO.cleanup()
	camera.stop_preview()




